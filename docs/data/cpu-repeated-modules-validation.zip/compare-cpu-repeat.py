import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent.parent

def read(name):
    return json.loads((root / 'artifacts' / name).read_text(encoding='utf-8-sig'))

def compare(before_name, after_name):
    before, after = read(before_name), read(after_name)
    assert before['failure'] is None and after['failure'] is None
    key = lambda row: (row['Name'], row['method'], row['useCuda'], row['repeat'])
    expected = {key(row): row for row in before['rows']}
    assert len(expected) == len(after['rows'])
    groups = {}
    for row in after['rows']:
        old = expected[key(row)]
        for field in ('Options', 'Parameters', 'Width', 'Height', 'TeachingRegion', 'Region'):
            assert old['log'][field] == row['log'][field], (key(row), field)
        for field in ('Matches', 'Evaluations', 'CandidatesTruncated', 'MatchLimitExceeded'):
            assert old['log']['Output']['Result'][field] == row['log']['Output']['Result'][field], (key(row), field)
        assert old['accuracyPassed'] == row['accuracyPassed']
        groups.setdefault(key(row)[:3], []).append((old, row))
    summary = []
    for group, pairs in groups.items():
        record = dict(zip(('Case', 'Method', 'Cuda'), group))
        for label, index in (('Before', 0), ('After', 1)):
            rows = [pair[index] for pair in pairs]
            # 변경 전 마지막 Chamfer CUDA 실행에 빌드가 겹쳤다. 시간 비교에는 양쪽 첫 두 회만 쓴다.
            if group == ('8k-full-modules', 'CpuDirectionalChamfer', True):
                rows = rows[:2]
            confirmed = all(row['displayConfirmed'] for row in rows)
            record[label] = {
                'TimingSamples': len(rows),
                'DisplayConfirmed': confirmed,
                'DisplayedMedian': statistics.median(row['displayedMs'] for row in rows) if confirmed else None,
                'DisplayedWarmMedian': statistics.median(row['displayedMs'] for row in rows if row['repeat'] > 0) if confirmed else None,
                'DisplayedMaximum': max(row['displayedMs'] for row in rows) if confirmed else None,
                'ObservedWaitMedian': statistics.median(row['displayedMs'] for row in rows),
                'ServiceMedian': statistics.median(row['log']['Output']['TotalMilliseconds'] for row in rows),
                'StagesMedian': {stage: statistics.median(row['log']['Output']['Result']['Timings'][stage] for row in rows)
                    for stage in ('Preparation', 'CoarseSearch', 'Refinement', 'Verification')},
            }
        row = pairs[-1][1]
        record.update(Count=len(row['log']['Output']['Result']['Matches']), Passed=row['accuracyPassed'],
            Truncated=row['log']['Output']['Result']['CandidatesTruncated'])
        summary.append(record)
        display = lambda value: round(value, 1) if value is not None else 'UNCONFIRMED'
        print(group, 'display', display(record['Before']['DisplayedMedian']), '->', display(record['After']['DisplayedMedian']),
              'exact', record['Count'], 'pass', record['Passed'], 'truncated', record['Truncated'])
    return summary

if __name__ == '__main__':
    import sys
    summary = compare(sys.argv[1], sys.argv[2])
    if len(sys.argv) > 3:
        (root / sys.argv[3]).write_text(json.dumps(summary, indent=2), encoding='utf-8')
