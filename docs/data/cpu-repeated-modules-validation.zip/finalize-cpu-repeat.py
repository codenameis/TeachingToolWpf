import hashlib
import json
import runpy
import statistics
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
artifacts = root / 'artifacts'
compare = runpy.run_path(str(artifacts / 'compare-cpu-repeat.py'))['compare']
read = lambda name: json.loads((artifacts / name).read_text(encoding='utf-8-sig'))

directional_name = 'cpu-repeat-boundary-only-modules.json'
ncc_name = 'cpu-repeat-final-ncc-modules.json'
directional, ncc = read(directional_name), read(ncc_name)
rows = [dict(row, SourceReport=directional_name) for row in directional['rows'] if row['method'] != 'CpuSubNcc']
rows += [dict(row, SourceReport=ncc_name) for row in ncc['rows']]
assert len(rows) == 36 and all(row['displayConfirmed'] for row in rows)
(artifacts / 'cpu-repeat-final-modules.json').write_text(json.dumps({
    'failure': None, 'rows': rows,
    'Sources': [directional_name, ncc_name],
    'Note': 'Derived report: retained directional implementations and separately measured restored NCC. No timings were synthesized.'
}, indent=2), encoding='utf-8')
modules = compare('cpu-repeat-before-modules.json', 'cpu-repeat-final-modules.json')
sparse = compare('cpu-repeat-before-full8k.json', 'cpu-repeat-final-full8k.json')

cli_pairs = [
    ('cpu-repeat-before-kensa.json', 'cpu-repeat-final-kensa.json'),
    ('cpu-speed-final-synthetic.json', 'cpu-repeat-final-synthetic.json'),
    ('cpu-speed-final-validation.json', 'cpu-repeat-final-validation.json'),
    ('cpu-speed-phase-suppression.json', 'cpu-repeat-final-phase.json'),
]
cli_count = 0
known_only = 0
for old_name, new_name in cli_pairs:
    old = read(old_name)
    new = read(new_name)
    key = lambda row: (row['Name'], row['Method'], row['Execution'])
    old_rows = {key(row): row for row in old['Rows'] if not row['Method'].startswith('OpenCv')}
    new_rows = [row for row in new['Rows'] if not row['Method'].startswith('OpenCv')]
    assert len(old_rows) == len(new_rows)
    for row in new_rows:
        before = old_rows[key(row)]
        for field in ('Found', 'Evaluations', 'CandidatesTruncated', 'MatchLimitExceeded', 'Options', 'ImageSha256', 'TemplateSha256'):
            assert before[field] == row[field], (new_name, key(row), field)
        assert row['CpuAgreement'] is not False
        assert row['KnownTargetsPassed']
        if not row['GroundTruthComplete']:
            known_only += 1
        cli_count += 1
assert cli_count == 174 and known_only == 6

summary = {'Modules': modules, 'Sparse': sparse, 'ExactCliComparisons': cli_count,
    'CliKnownTargetsOnly': known_only, 'ExactWpfComparisons': 54, 'CpuCudaCliPairs': 87}
(artifacts / 'cpu-repeat-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')

names = {'CpuLine2D': 'Line2D', 'CpuSubNcc': 'Sub-NCC', 'CpuDirectionalChamfer': 'Chamfer'}
tables = []
for title, records in [('기본8K256핀 전체', [r for r in modules if r['Case'] == '8k-full-modules']),
                       ('Kensa 전체48개', [r for r in modules if r['Case'] == 'kensa-full-modules']),
                       ('기존 희소8K8개 전체', sparse)]:
    tables += ['### ' + title, '', '| 방식 | 장치 | 이전 버튼→표시(ms) | 이후 버튼→표시(ms) | 이후 최대(ms) |', '|---|---|---:|---:|---:|']
    for method in names:
        for cuda in (False, True):
            r = next(r for r in records if r['Method'] == method and r['Cuda'] == cuda)
            b, a = r['Before'], r['After']
            tables.append(f"|{names[method]}|{'CPU+CUDA' if cuda else 'CPU'}|{b['DisplayedMedian']:.1f}|{a['DisplayedMedian']:.1f}|{a['DisplayedMaximum']:.1f}|")
    tables.append('')
tables += ['Sub-NCC는 구현을 원복했는데도 시간이 늘었다. 다른 프로세스 부하가 관측되었고 CPU/JIT·실행 순서·열 상태를 완전히 통제하지 못했다. 따라서 작은 시간 차이나 NCC의 변화는 최적화 효과로 주장하지 않는다. 방향 맵 재사용의 큰 이득과 행 병렬화의 후보 단계 감소를 구별하며, 모든 조건에서 빨라졌다고 표현하지 않는다.', '']

validation = '''- PASS: CPU13 + CUDA63 + WPF/검사299 = **375개 테스트**, Release 빌드 경고0/오류0. 변경 C# 파일 공백·스타일·명명 검사 통과. 저장소 전체 형식 검사는 재실행하지 않았으며 이전54개 범위 밖 위반은 그대로다.
- PASS: 새 캐시는 동일 타일4회 준비→2회, 한 픽셀 변경 시3회로 분리하며 결과·평가 수가 같다. 이미지 끝의 다른 크기와 외부 순차 전략도 확인했다.
- PASS: 기존29조건×3방식×2장치=**174건**의 입력 해시·옵션·결과·평가 수·잘림 플래그가 이전과 정확히 같다. CPU/CUDA87조합 일치. 완전 정답168건 합격, 원본18V6건은 알려진 대상만 확인했다. Kensa는10회 준비 뒤3회, 나머지 회귀는10회 준비 뒤1회 측정했으며 첫 실행도 별도 기록했다.
- PASS: 최종 WPF 반복 모듈36회 + 희소8K18회 = **54회** 표시 확인과 전후 결과·평가 수 동일. 모듈 결과는 Line2D/Chamfer 최종 실행24회와 NCC 원복 후 별도 실행12회를 출처와 함께 합산했다. 정확도 합격54회를 뜻하지 않는다.
- FAIL: 반복 모듈의 후보 잘림/NCC 위치 정확도와125/80ms. 희소8K18회는 검출·위치·각도 기준을 통과했지만 시간은 모두 미달이다.
'''
doc = root / 'docs/cpu-matching-repeated-modules.md'
content = doc.read_text(encoding='utf-8')
content = content.replace('<!-- REPEATED_RESULTS -->', '\n'.join(tables))
content = content.replace('<!-- REPEATED_VALIDATION -->', validation)
doc.write_text(content, encoding='utf-8')

source_names = subprocess.check_output(['git', 'diff', '--name-only', '--', '*.cs'], cwd=root, text=True).splitlines()
manifest = {
    'Checkpoint': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'FinalSources': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in source_names},
    'UnchangedNccSourceSha256': hashlib.sha256((root / 'src/CpuMatching.SubNcc/SubNccMatcher.cs').read_bytes()).hexdigest(),
    'Interpretation': 'Algorithm equality is exact. WPF timing has observed environment variance; no 125/80ms claim.'
}
(artifacts / 'cpu-repeat-source-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
files = ['cpu-repeat-before-modules.json', directional_name, ncc_name, 'cpu-repeat-final-modules.json',
    'cpu-repeat-before-full8k.json', 'cpu-repeat-parallel-full8k.json', 'cpu-repeat-ncc-full8k.json',
    'cpu-repeat-final-full8k.json', 'cpu-repeat-sharing-all-modules.json', 'cpu-repeat-baseline-accuracy.json',
    'cpu-repeat-summary.json', 'cpu-repeat-source-manifest.json', 'compare-cpu-repeat.py',
    'finalize-cpu-repeat.py', 'cpu-repeat-final-tests.log', 'cpu-repeat-build.log', 'cpu-repeat-style.log']
files += [name for pair in cli_pairs for name in pair]
with zipfile.ZipFile(root / 'docs/data/cpu-repeated-modules-validation.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in dict.fromkeys(files):
        archive.write(artifacts / name, name)
print('Exact validation:', cli_count, 'CLI and 54 WPF; archived', len(set(files)), 'files.')
