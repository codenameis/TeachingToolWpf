import collections
import json
import sys
from pathlib import Path

trace = json.loads(Path(sys.argv[1]).read_text())
names = [frame['name'] for frame in trace['shared']['frames']]
exclusive = collections.Counter()
inclusive = collections.Counter()
for profile in trace['profiles']:
    stack = []
    last = profile['startValue']
    for event in profile['events']:
        duration = event['at'] - last
        if stack and any('PrimitiveShapeDetector.Detect' in names[f] for f in stack):
            exclusive[names[stack[-1]]] += duration
            for frame in set(stack):
                inclusive[names[frame]] += duration
        if event['type'] == 'O':
            stack.append(event['frame'])
        else:
            assert stack.pop() == event['frame']
        last = event['at']
for label, counter in [('exclusive', exclusive), ('inclusive', inclusive)]:
    print(label)
    for name, duration in counter.most_common(35):
        print(f'{duration:.1f} {name}')
