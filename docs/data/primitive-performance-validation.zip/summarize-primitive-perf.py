import json
import statistics
from pathlib import Path

groups = {
    'cpuBefore': ['primitive-final-before-cpu.jsonl'],
    'cpuAfter': ['primitive-final-after-cpu.jsonl'],
    'gpuBefore': ['primitive-final-before-gpu.jsonl', 'primitive-final-before-gpu-repeat.jsonl'],
    'gpuAfter': ['primitive-final-after-gpu.jsonl', 'primitive-final-after-gpu-repeat.jsonl'],
}
summary = {}
for name, files in groups.items():
    records = [json.loads(line) for file in files for line in Path('artifacts', file).read_text(encoding='utf-8-sig').splitlines()]
    runs = [r for r in records if r.get('run', 0) > 0]
    assert all(r['found'] == r['expected'] == 16384 and not r['Incomplete'] and not r['ClippedContours']
        and r['duplicateCount'] == r['kindErrors'] == 0 and not r['missingByKindAndAngle'] for r in runs)
    values = {field: [r[field] for r in runs] for field in ['DetectionMilliseconds', 'Milliseconds',
        'requestMilliseconds', 'ReadMilliseconds', 'ComputeInitializationMilliseconds', 'detectionAllocatedBytes', 'peakWorkingSet']}
    summary[name] = {'files': files, 'samples': len(runs), 'hashes': sorted({r['hash'] for r in runs}),
        'maxCenterError': max(r['maxError'] for r in runs), 'maxAngleError': max(r['maxAngleErrorDegrees'] for r in runs),
        'timings': {field: {'median': statistics.median(v), 'min': min(v), 'max': max(v)} for field, v in values.items()}}
Path('artifacts/primitive-performance-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
for name in ['unpinned1', 'pinned', 'unpinned2', 'direct', 'unpinned3']:
    runs = [r for line in Path(f'artifacts/primitive-ab-gpu-{name}.jsonl').read_text(encoding='utf-8-sig').splitlines()
        if (r := json.loads(line)).get('run', 0) >= 2]
    print(name, statistics.median(r['DetectionMilliseconds'] for r in runs))
