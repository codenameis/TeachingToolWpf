using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Text;

if (args.Contains("--verify-backups"))
{
    var count = 0;
    var backupRoot = "artifacts/final-quality-review/layout-before";
    foreach (var backup in Directory.EnumerateFiles(backupRoot, "*.cs", SearchOption.AllDirectories))
    {
        var path = Path.GetRelativePath(backupRoot, backup);
        var before = CSharpSyntaxTree.ParseText(File.ReadAllText(backup)).GetRoot();
        var after = CSharpSyntaxTree.ParseText(File.ReadAllText(path)).GetRoot();
        if (!before.DescendantTokens().Select(token => (token.RawKind, token.Text))
            .SequenceEqual(after.DescendantTokens().Select(token => (token.RawKind, token.Text))))
            throw new InvalidOperationException($"Layout tokens changed: {path}");
        count++;
    }
    Console.WriteLine($"Verified {count} layout backups: all code tokens and literal values preserved.");
    return;
}

var git = new ProcessStartInfo("git") { RedirectStandardOutput = true, UseShellExecute = false };
git.ArgumentList.Add("ls-files");
git.ArgumentList.Add("*.cs");
using var process = Process.Start(git)!;
var paths = process.StandardOutput.ReadToEnd().Split('\n', StringSplitOptions.RemoveEmptyEntries)
    .Select(path => path.TrimEnd('\r'))
    .Where(path => new[] { "src/", "tests/", "benchmarks/", "samples/" }.Any(path.StartsWith)).ToArray();
process.WaitForExit();
if (process.ExitCode != 0) throw new InvalidOperationException("git ls-files failed.");
var report = new List<object>();
foreach (var path in paths)
{
    var original = File.ReadAllText(path);
    var source = SourceText.From(original);
    var root = CSharpSyntaxTree.ParseText(source).GetRoot();
    var edits = new List<TextChange>();
    foreach (var loop in root.DescendantNodes().OfType<ForStatementSyntax>())
    {
        var span = TextSpan.FromBounds(loop.OpenParenToken.Span.End, loop.CloseParenToken.Span.Start);
        var header = original.Substring(span.Start, span.Length);
        if (!header.Contains('\n')) continue;
        if (loop.DescendantTrivia().Any(trivia => span.Contains(trivia.Span) &&
            !trivia.IsKind(SyntaxKind.WhitespaceTrivia) && !trivia.IsKind(SyntaxKind.EndOfLineTrivia))) continue;
        if (loop.DescendantTokens().Any(token => span.Contains(token.Span) && token.Text.Contains('\n'))) continue;
        var line = source.Lines.GetLineFromPosition(loop.ForKeyword.SpanStart);
        var indentation = loop.ForKeyword.SpanStart - line.Start;
        var joined = Regex.Replace(header, @"\r?\n\s*", " ");
        var replacement = indentation + joined.Length + 6 <= 180 ? joined
            : Regex.Replace(header, @"\r?\n\s*", "\r\n" + new string(' ', indentation + 4));
        if (replacement != header) edits.Add(new(span, replacement));
    }
    if (edits.Count == 0) continue;
    var revised = source.WithChanges(edits).ToString();
    var updated = CSharpSyntaxTree.ParseText(revised).GetRoot();
    static IEnumerable<(int Kind, string Text)> Tokens(SyntaxNode node)
        => node.DescendantTokens().Select(token => (token.RawKind, token.Text));
    if (!Tokens(root).SequenceEqual(Tokens(updated))) throw new InvalidOperationException($"Token changed: {path}");
    if (args.Contains("--write"))
    {
        var backup = Path.Combine("artifacts/final-quality-review/layout-before", path);
        Directory.CreateDirectory(Path.GetDirectoryName(backup)!);
        if (!File.Exists(backup)) File.Copy(path, backup);
        File.WriteAllText(path, revised, new UTF8Encoding(false));
    }
    report.Add(new { Path = path, ForHeaders = edits.Count, TokensUnchanged = true });
}
File.WriteAllText("artifacts/final-quality-review/layout-audit.json", JsonSerializer.Serialize(report,
    new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"First-party files inspected: {paths.Length}; files with multiline for headers: {report.Count}; write={args.Contains("--write")}");
foreach (var entry in report) Console.WriteLine(JsonSerializer.Serialize(entry));
