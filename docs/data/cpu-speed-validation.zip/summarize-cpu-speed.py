import csv, hashlib, json, math, statistics, zipfile
from pathlib import Path

def read(name): return json.loads(Path('artifacts',name).read_text(encoding='utf-8-sig'))
methods=['Line2D','SubNcc','DirectionalChamfer']
rows=[]; exact={m:0 for m in methods}; changed={m:[] for m in methods}
inputs=0
for group in ['kensa','synthetic','validation']:
    before=read(f'cpu-speed-before-{group}.json')['Rows']
    after=read(f'cpu-speed-final-{group}.json')['Rows']
    baseline={(r['Name'],r['Method'],r['Execution']):r for r in before}
    for r in after:
        if r['Method'] not in methods: continue
        old=baseline[(r['Name'],r['Method'],r['Execution'])]
        assert all(old[k]==r[k] for k in ['Options','ImageSha256','TemplateSha256']),r['Name']
        assert r['KnownTargetsPassed'] and r['CpuAgreement'] is not False,r['Name']
        inputs+=1
        same=all(old[k]==r[k] for k in ['Found','Evaluations','CandidatesTruncated','MatchLimitExceeded'])
        exact[r['Method']]+=same
        if not same: changed[r['Method']].append(r['Name']+'/'+r['Execution'])
        rows.append(dict(Case=r['Name'],Method=r['Method'],Execution=r['Execution'],BeforeMs=old['MedianMs'],AfterMs=r['MedianMs'],ExactBeforeAfter=same,
            PreparationMs=r['Timings']['Preparation'],CoarseMs=r['Timings']['CoarseSearch'],RefinementMs=r['Timings']['Refinement'],VerificationMs=r['Timings']['Verification']))
with open('docs/cpu-speed-algorithm-summary.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
phases=[r for r in read('cpu-speed-phase-suppression.json')['Rows'] if r['Method'] in methods]
assert len(phases)==48 and all(r['Passed'] and r['CpuAgreement'] is not False for r in phases)
summary=dict(FixedInputOptionComparisons=inputs,ExactBeforeAfter=exact,Changed=changed,PhaseChecks=len(phases))

bounded=read('cpu-speed-final-wpf.json'); full=read('cpu-full8k-wpf.json')
assert bounded['failure'] is None and len(bounded['rows'])==126
assert full['failure'] is None and len(full['rows'])==18
assert all(r['accuracyPassed'] and r['displayConfirmed'] for r in bounded['rows']+full['rows'])
truth=json.loads(Path('samples/CpuMatching.FullImage/cases.json').read_text())
summary['WpfAccuracyChecks']=144
summary['WpfCpuCudaExact']=0
for report in [bounded,full]:
    for name in dict.fromkeys(r['Name'] for r in report['rows']):
        for method in methods:
            selected=[r for r in report['rows'] if r['Name']==name and r['method']=='Cpu'+method]
            cpu=next(r for r in selected if not r['useCuda'])['log']['Output']['Result']
            for r in selected:
                actual=r['log']['Output']['Result']
                assert all(cpu[k]==actual[k] for k in ['Matches','Evaluations','CandidatesTruncated','MatchLimitExceeded']),(name,method)
                if r['useCuda']:summary['WpfCpuCudaExact']+=1
for r in full['rows']:
    log=r['log']; assert log['Region'] is None and log['Width']==log['Height']==8192
    assert log['Output']['Result']['Evaluations']>=2048*2048*7
    found=log['Output']['Result']['Matches']
    assert len(found)==8
    for e in truth[0]['Expected']:
        m=min(found,key=lambda m:math.hypot(m['X']-e['X']-.5,m['Y']-e['Y']-.5))
        assert math.hypot(m['X']-e['X']-.5,m['Y']-e['Y']-.5)<=1
        assert abs((m['AngleDegrees']-e['AngleDegrees']+180)%360-180)<=1
        assert abs(m['Scale']-e['Scale'])<=.03

timing=[]
for label,report,before in [('Bounded',bounded,read('cpu-speed-button-before-wpf.json')),('Full8K',full,read('cpu-full8k-before-local-maps.json'))]:
    for name in dict.fromkeys(r['Name'] for r in report['rows']):
        for method in methods:
            for cuda in [False,True]:
                group=[r for r in report['rows'] if (r['Name'],r['method'],r['useCuda'])==(name,'Cpu'+method,cuda)]
                old=[r['displayedMs'] for r in before['rows'] if (r['Name'],r['method'],r['useCuda'])==(name,'Cpu'+method,cuda)]
                values=[r['displayedMs'] for r in group]
                target=80 if cuda else 125
                timing.append(dict(Scope=label,Case=name,Method=method,Execution='CPU+CUDA' if cuda else 'CPU',BeforeMedianMs=statistics.median(old),
                    MedianMs=statistics.median(values),FirstMs=values[0],WarmMedianMs=statistics.median(values[1:]),MaxMs=max(values),TargetMs=target,WithinTarget=sum(v<=target for v in values),Runs=len(values)))
with open('docs/cpu-speed-display-summary.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,timing[0].keys());w.writeheader();w.writerows(timing)
summary['Display']=timing
summary['MemoryBefore']=read('cpu-full8k-before-process.json')
summary['MemoryAfter']=read('cpu-full8k-process.json')
Path('artifacts/cpu-speed-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['Display','Changed']},ensure_ascii=False,indent=2))
for row in timing:
    if row['Scope']=='Full8K' or row['Case']=='kensa-component-original':print(row)
