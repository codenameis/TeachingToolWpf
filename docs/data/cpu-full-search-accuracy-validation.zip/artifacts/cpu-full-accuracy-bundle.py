import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
artifacts = root / 'artifacts'
sources = [path for folder in ('src/CpuMatching.Core', 'src/CpuMatching.Cuda',
    'src/CpuMatching.Line2D', 'src/CpuMatching.SubNcc', 'src/CpuMatching.DirectionalChamfer')
    for path in (root / folder).glob('*.cs')]
sources += [root / path for path in (
    'src/TeachingToolWpf/Diagnostics/CpuKensaComparisonRun.cs',
    'tests/CpuMatching.Tests/FullSearchAccuracyTests.cs',
    'tests/VisionCompute.Tests/CudaTemplateMatchingTests.cs',
    'tools/CpuMatching.Evaluation/FullModuleDataset.cs')]
manifest = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    branch=subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip(),
    policy='Local changes and validation only; no commit or push.',
    sources={str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
    dataset={str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in (root / 'samples/CpuMatching.Modules').iterdir() if path.is_file()})
(artifacts / 'cpu-full-accuracy-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
(artifacts / 'cpu-full-accuracy.patch').write_bytes(subprocess.check_output(['git', 'diff', '--'], cwd=root))

files = list(artifacts.glob('cpu-full-accuracy*'))
files += [artifacts / name for name in (
    'cpu-accuracy-exhaustive-modules.json', 'cpu-accuracy-red.log', 'cpu-candidate-red.log',
    'cpu-content-cache-red.log', 'cpu-content-cache-tests.log', 'cpu-locality-tests.log',
    'cpu-accuracy-before-edge-reuse.json', 'cpu-accuracy-after-edge-reuse.json', 'cpu-directions.ptx',
    'cpu-wpf-kensa-full-modules-CpuSubNcc-cpu.png', 'cpu-wpf-8k-full-modules-CpuSubNcc-cpu.png')]
files += list((artifacts / 'cpu-accuracy-probe').glob('*.json'))
files += [artifacts / ('cpu-repeat-final-' + name + '.json') for name in ('kensa', 'synthetic', 'validation', 'phase')]
files += list((root / 'tests/CpuMatching.Tests/Data').iterdir())
files += list((root / 'samples/CpuMatching.Modules').glob('*.json'))
files += sources
files += [root / 'docs/cpu-matching-full-search-accuracy.md', root / 'docs/decisions/0063-exhaustive-candidates-and-fine-pose-ranking.md']
destination = root / 'docs/data/cpu-full-search-accuracy-validation.zip'
with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(set(files)):
        if path.is_file():
            archive.write(path, str(path.relative_to(root)))
print(destination, destination.stat().st_size)
