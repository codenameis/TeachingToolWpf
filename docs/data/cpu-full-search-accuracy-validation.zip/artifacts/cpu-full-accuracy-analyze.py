import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent.parent
artifacts = root / 'artifacts'

def read(name):
    return json.loads((artifacts / name).read_text(encoding='utf-8-sig'))

def result(row):
    return {key: value for key, value in row['log']['Output']['Result'].items() if key != 'Timings'}

def key(row):
    return row['Name'], row['method'], row['useCuda'], row['repeat']

def summarize_wpf(name, baseline=None):
    report = read(name)
    rows = report['rows']
    assert report['failure'] is None, report['failure']
    assert all(row['accuracyPassed'] and row['displayConfirmed'] for row in rows)
    groups = {}
    for row in rows:
        groups.setdefault(key(row)[:3], []).append(row)
    before = {key(row): row for row in read(baseline)['rows']} if baseline else {}
    pairs = 0
    summaries = []
    for group, values in groups.items():
        for row in values:
            assert result(row) == result(values[0]), ('repeat mismatch', key(row))
            if before:
                assert result(row) == result(before[key(row)]), ('result mismatch', key(row))
                for field in ('Options', 'Parameters', 'Region', 'TeachingRegion'):
                    assert row['log'][field] == before[key(row)]['log'][field], ('conditions mismatch', key(row), field)
        if group[2]:
            cpu = groups[group[:2] + (False,)]
            for left, right in zip(cpu, values):
                assert result(left) == result(right), ('CPU/CUDA mismatch', group)
                pairs += 1
        summary = dict(case=group[0], method=group[1], cuda=group[2], runs=len(values),
            matches=len(result(values[0])['Matches']), candidates=result(values[0])['CandidateCount'],
            batches=result(values[0])['CandidateBatches'], evaluations=result(values[0])['Evaluations'],
            maxPositionPx=max(row['maximumPositionError'] for row in values),
            maxAngleDegrees=max(row['maximumAngleError'] for row in values),
            firstMs=values[0]['displayedMs'], medianMs=statistics.median(row['displayedMs'] for row in values),
            maxMs=max(row['displayedMs'] for row in values),
            stages={stage: statistics.median(row['log']['Output']['Result']['Timings'][stage] for row in values)
                    for stage in values[0]['log']['Output']['Result']['Timings']})
        if before:
            summary['baselineMedianMs'] = statistics.median(before[key(row)]['displayedMs'] for row in values)
            summary['baselineMaxMs'] = max(before[key(row)]['displayedMs'] for row in values)
            summary['reductionPercent'] = 100 * (1 - summary['medianMs'] / summary['baselineMedianMs'])
        summaries.append(summary)
    return dict(rows=len(rows), cpuCudaPairsExact=pairs, baselineResultAndConditionsExact=bool(before), groups=summaries)

rounded_name = 'cpu-full-accuracy-rounded-modules.json'
if (artifacts / rounded_name).exists():
    rounded = read(rounded_name)
    assert rounded['failure'] is None and len(rounded['rows']) == 12
    original = read('cpu-full-accuracy-pre-rounding-modules.json')
    replacements = {key(row): row for row in rounded['rows']}
    original['rows'] = [replacements.get(key(row), row) for row in original['rows']]
    original['created'] = rounded['created']
    original['sources'] = {
        'Line2D and SubNcc, unchanged score paths, 24 rows': 'cpu-full-accuracy-pre-rounding-modules.json',
        'Chamfer CPU/CUDA after strict interpolation, 12 rows': rounded_name}
    (artifacts / 'cpu-full-accuracy-final-modules.json').write_text(json.dumps(original, indent=2), encoding='utf-8')

summary = {}
for name, baseline, label in [
    ('cpu-full-accuracy-final-modules.json', 'cpu-accuracy-exhaustive-modules.json', 'modules'),
    ('cpu-full-accuracy-final-sparse.json', None, 'sparse')]:
    if (artifacts / name).exists():
        summary[label] = summarize_wpf(name, baseline)
cli = []
for label in ('kensa', 'synthetic', 'validation', 'phase'):
    name = 'cpu-full-accuracy-final-' + label + '.json'
    if not (artifacts / name).exists():
        continue
    rows = [row for row in read(name)['Rows'] if row['Method'] in ('Line2D', 'SubNcc', 'DirectionalChamfer')]
    original = {(row['Name'], row['Method'], row['Execution']): row for row in read('cpu-repeat-final-' + label + '.json')['Rows']}
    for row in rows:
        assert row['KnownTargetsPassed'], ('CLI accuracy', label, row['Name'], row['Method'])
        assert not row['GroundTruthComplete'] or row['Passed']
        old = original[row['Name'], row['Method'], row['Execution']]
        for field in ('Options', 'ImageSha256', 'TemplateSha256'):
            assert row[field] == old[field], ('CLI input mismatch', label, field)
        if row['Execution'] == 'CPU+CUDA':
            cpu = next(other for other in rows if other['Name'] == row['Name'] and other['Method'] == row['Method'] and other['Execution'] == 'CPU')
            for field in ('Found', 'Evaluations', 'CandidateCount', 'CandidateBatches', 'CandidatesTruncated', 'MatchLimitExceeded'):
                assert row[field] == cpu[field], ('CLI CPU/CUDA mismatch', label, field)
    cli.extend(rows)
if cli:
    summary['cli'] = dict(rows=len(cli), completePassed=sum(row['Passed'] for row in cli),
        knownOnlyPassed=sum(not row['GroundTruthComplete'] and row['KnownTargetsPassed'] for row in cli),
        cpuCudaPairsExact=sum(row['Execution'] == 'CPU+CUDA' for row in cli), inputHashesAndOptionsUnchanged=True)
(artifacts / 'cpu-full-accuracy-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
