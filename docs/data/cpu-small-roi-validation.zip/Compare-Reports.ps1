param([string[]]$Before, [string[]]$After, [string]$Output)
$ErrorActionPreference = 'Stop'
function Read-Reports([string[]]$Paths) {
    foreach ($path in $Paths) { Get-Content -LiteralPath $path -Raw | ConvertFrom-Json }
}
function Median($values) {
    $sorted = @($values | Sort-Object)
    ($sorted[[int][math]::Floor(($sorted.Count-1)/2)] + $sorted[[int][math]::Floor($sorted.Count/2)]) / 2
}
$beforeReports = @(Read-Reports $Before)
$afterReports = @(Read-Reports $After)
$beforeRows = @($beforeReports.Rows)
$afterRows = @($afterReports.Rows)
$inputReference = $beforeReports[0].Inputs | ConvertTo-Json -Depth 10 -Compress
foreach ($report in @($beforeReports) + @($afterReports)) {
    if (($report.Inputs | ConvertTo-Json -Depth 10 -Compress) -cne $inputReference) { throw 'Input hashes differ.' }
}
$expectedKeys = @($beforeRows | ForEach-Object { $_.Name + '/' + $_.Method } | Sort-Object -Unique)
$actualKeys = @($afterRows | ForEach-Object { $_.Name + '/' + $_.Method } | Sort-Object -Unique)
if (($expectedKeys -join '|') -cne ($actualKeys -join '|')) { throw 'Case/method coverage differs.' }
$summary = foreach ($group in $beforeRows | Group-Object Name,Method) {
    $reference = $group.Group[0]
    $matchingAfter = @($afterRows | Where-Object { $_.Name -eq $reference.Name -and $_.Method -eq $reference.Method })
    $all = @($group.Group) + $matchingAfter
    if (@($all.ResultFingerprint | Sort-Object -Unique).Count -ne 1) { throw "Result/pose/score/candidate/evaluation mismatch: $($group.Name)" }
    if (@($all | ForEach-Object { $_.Options | ConvertTo-Json -Depth 10 -Compress } | Sort-Object -Unique).Count -ne 1) { throw 'Search options differ.' }
    $b = @($group.Group | Where-Object Round -ge 0)
    $a = @($matchingAfter | Where-Object Round -ge 0)
    $bm = Median $b.TotalMs
    $am = Median $a.TotalMs
    [pscustomobject]@{
        Name = $reference.Name
        Method = $reference.Method
        BeforeSamples = $b.Count
        AfterSamples = $a.Count
        BeforeMedianMs = $bm
        AfterMedianMs = $am
        GainPercent = (1 - $am/$bm) * 100
        BeforeMinMs = ($b.TotalMs | Measure-Object -Minimum).Minimum
        BeforeMaxMs = ($b.TotalMs | Measure-Object -Maximum).Maximum
        AfterMinMs = ($a.TotalMs | Measure-Object -Minimum).Minimum
        AfterMaxMs = ($a.TotalMs | Measure-Object -Maximum).Maximum
        BeforePreparationMs = Median $b.Result.Timings.Preparation
        AfterPreparationMs = Median $a.Result.Timings.Preparation
        BeforeRefinementMs = Median $b.Result.Timings.Refinement
        AfterRefinementMs = Median $a.Result.Timings.Refinement
        BeforeAllocatedBytes = Median $b.AllocatedBytes
        AfterAllocatedBytes = Median $a.AllocatedBytes
        ResultIdentical = $true
        Result = $reference.Result
    }
}
$summary | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $Output -Encoding utf8
$summary | Select-Object Name,Method,@{n='Before';e={[math]::Round($_.BeforeMedianMs,3)}},@{n='After';e={[math]::Round($_.AfterMedianMs,3)}},@{n='Gain%';e={[math]::Round($_.GainPercent,1)}},ResultIdentical | Format-Table -AutoSize
