param([string]$Dataset,[string]$Report,[string]$Output)
$ErrorActionPreference='Stop'
$cases=Get-Content -LiteralPath (Join-Path $Dataset 'cases.json') -Raw | ConvertFrom-Json
$reportData=Get-Content -LiteralPath $Report -Raw | ConvertFrom-Json
$summary=foreach($row in $reportData.Rows | Where-Object Round -eq 0) {
    $item=$cases | Where-Object Name -eq $row.Name
    $found=@($row.Result.Matches)
    $used=[Collections.Generic.HashSet[int]]::new()
    $positions=@()
    $angles=@()
    $scales=@()
    foreach($target in $item.Expected) {
        $nearest=-1
        $distance=[double]::PositiveInfinity
        for($index=0;$index -lt $found.Count;$index++) {
            if($used.Contains($index)) {continue}
            $candidate=$found[$index]
            $d=[math]::Sqrt([math]::Pow($candidate.X-$target.X,2)+[math]::Pow($candidate.Y-$target.Y,2))
            if($d -lt $distance) { $distance=$d; $nearest=$index }
        }
        $positions+=$distance
        if($nearest -ge 0) {
            [void]$used.Add($nearest)
            $angles+=[math]::Abs((($found[$nearest].AngleDegrees-$target.AngleDegrees+540)%360)-180)
            $scales+=[math]::Abs($found[$nearest].Scale-$target.Scale)
        } else { $angles+=[double]::PositiveInfinity; $scales+=[double]::PositiveInfinity }
    }
    $knownPassed=@($positions|Where-Object {$_ -gt 1}).Count -eq 0 -and @($angles|Where-Object {$_ -gt 1}).Count -eq 0 -and @($scales|Where-Object {$_ -gt .03}).Count -eq 0
    $complete=$item.GroundTruthComplete -ne $false
    $passed=$knownPassed -and $found.Count -eq @($item.Expected).Count -and -not $row.Result.CandidatesTruncated -and -not $row.Result.MatchLimitExceeded
    [pscustomobject]@{
        Name=$row.Name; Method=$row.Method; CompleteLabels=$complete
        Expected=@($item.Expected).Count; Found=$found.Count
        KnownTargetsPassed=$knownPassed
        Passed=if($complete){$passed}else{$null}
        MaximumPositionError=($positions|Measure-Object -Maximum).Maximum
        MaximumAngleError=($angles|Measure-Object -Maximum).Maximum
        MaximumScaleError=($scales|Measure-Object -Maximum).Maximum
    }
}
$summary | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $Output -Encoding utf8
$summary | Format-Table -AutoSize
if(@($summary|Where-Object {$_.CompleteLabels -and -not $_.Passed}).Count) { throw 'Complete-label accuracy failed.' }
