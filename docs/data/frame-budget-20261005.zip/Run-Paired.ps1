$ErrorActionPreference = 'Stop'
$output = 'src/TeachingToolWpf/bin/Release/net10.0-windows'
$canvas = "$output/VisionCanvas.dll"
$core = "$output/VisionCanvas.Core.dll"
Copy-Item -LiteralPath $canvas -Destination 'artifacts/frame-budget/canvas-after.dll'
Copy-Item -LiteralPath $core -Destination 'artifacts/frame-budget/core-after.dll'
$hashes = [ordered]@{
    app = (Get-FileHash -LiteralPath "$output/TeachingToolWpf.dll").Hash
    canvasBefore = (Get-FileHash -LiteralPath 'artifacts/frame-budget/canvas-before.dll').Hash
    canvasAfter = (Get-FileHash -LiteralPath 'artifacts/frame-budget/canvas-after.dll').Hash
    coreBefore = (Get-FileHash -LiteralPath 'artifacts/frame-budget/core-before.dll').Hash
    coreAfter = (Get-FileHash -LiteralPath 'artifacts/frame-budget/core-after.dll').Hash
}
$hashes | ConvertTo-Json | Set-Content -LiteralPath 'artifacts/frame-budget/binaries.json'
try {
    foreach ($iteration in 1..3) {
        foreach ($variant in @('before', 'after')) {
            Copy-Item -LiteralPath "artifacts/frame-budget/canvas-$variant.dll" -Destination $canvas
            Copy-Item -LiteralPath "artifacts/frame-budget/core-$variant.dll" -Destination $core
            $stem = "artifacts/frame-budget/paired-$variant-$iteration"
            $run = Start-Process -FilePath "$output/TeachingToolWpf.exe" -ArgumentList @('--frame-cadence-check', '--rois', '40000', '--cadence-report', "$stem.json", '--render-profile', "$stem-render.csv", '--metrics', "$stem-metrics.csv") -WindowStyle Hidden -PassThru
            $run.WaitForExit()
            if ($run.ExitCode -ne 0) { throw "Failed $stem exit $($run.ExitCode)" }
            $report = Get-Content -LiteralPath "$stem.json" -Raw | ConvertFrom-Json
            if ($report.stage -ne 'complete' -or $report.error -or -not $report.undoExact -or -not $report.redoExact) { throw "Incomplete $stem" }
            Write-Output "$stem exact=True exit=0"
        }
    }
} finally {
    Copy-Item -LiteralPath 'artifacts/frame-budget/canvas-after.dll' -Destination $canvas
    Copy-Item -LiteralPath 'artifacts/frame-budget/core-after.dll' -Destination $core
}
