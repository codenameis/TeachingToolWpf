$ErrorActionPreference = 'Stop'
$paths = @(Get-ChildItem -LiteralPath 'artifacts/frame-budget' -Filter 'paired-*.json' |
    Where-Object Name -Match '^paired-(before|after)-[1-3]\.json$' | ForEach-Object FullName)
./scripts/Summarize-FrameCadence.ps1 -Path $paths | Set-Content -LiteralPath 'artifacts/frame-budget/paired-summary.json'
$summary = Get-Content -LiteralPath 'artifacts/frame-budget/paired-summary.json' -Raw | ConvertFrom-Json
$runs = @(foreach ($item in $summary) {
    $report = Get-Content -LiteralPath $item.file -Raw | ConvertFrom-Json
    $phase = $report.phases | Where-Object name -eq $item.phase
    $stem = [IO.Path]::ChangeExtension($item.file, $null).TrimEnd('.')
    $frames = @(Import-Csv -LiteralPath "$stem-render.csv" | Where-Object {
        [long]$_.stopwatch_start_ticks -ge $phase.startTicks -and [long]$_.stopwatch_end_ticks -le $phase.endTicks
    })
    $worst = $frames | Sort-Object {[double]$_.submit_ms} -Descending | Select-Object -First 1
    [pscustomobject]@{
        file = [IO.Path]::GetFileName($item.file)
        variant = $(if ($item.file -match 'paired-before') { 'before' } else { 'after' })
        phase = $item.phase
        submitMax = $item.renderSubmitMs.max
        presentMax = $item.presentReturnIntervalMs.max
        presentP95 = $item.presentReturnIntervalMs.p95
        inputSlotMax = $item.inputPendingSlotMs.max
        inputAppliedMax = $item.inputAppliedIntervalMs.max
        inputSkippedPeriods = $item.inputSkippedPeriods
        gcPauseMs = $item.gcPauseMs
        worstPackMs = [double]$worst.roi_pack_ms
        worstCreateMs = [double]$worst.roi_create_ms
        worstUploadMs = [double]$worst.roi_upload_ms
        worstAllocatedBytes = [long]$worst.allocated_bytes
        totalUploadBytes = ($frames | ForEach-Object {[long]$_.roi_upload_bytes} | Measure-Object -Sum).Sum
    }
})
$runs | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath 'artifacts/frame-budget/paired-stages.json'
$runs | Group-Object variant,phase | ForEach-Object {
    [pscustomobject]@{
        group = $_.Name
        submitPeakMean = ($_.Group.submitMax | Measure-Object -Average).Average
        presentPeakMean = ($_.Group.presentMax | Measure-Object -Average).Average
        presentWorst = ($_.Group.presentMax | Measure-Object -Maximum).Maximum
        packPeakMean = ($_.Group.worstPackMs | Measure-Object -Average).Average
        createPeakMean = ($_.Group.worstCreateMs | Measure-Object -Average).Average
        allocatedPeakMean = ($_.Group.worstAllocatedBytes | Measure-Object -Average).Average
        inputSlotWorst = ($_.Group.inputSlotMax | Measure-Object -Maximum).Maximum
        gcPauseMean = ($_.Group.gcPauseMs | Measure-Object -Average).Average
        uploadMean = ($_.Group.totalUploadBytes | Measure-Object -Average).Average
    }
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath 'artifacts/frame-budget/paired-aggregate.json'
Get-Content -LiteralPath 'artifacts/frame-budget/paired-aggregate.json' -Raw | ConvertFrom-Json | Format-Table -AutoSize
