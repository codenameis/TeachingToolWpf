$ErrorActionPreference = 'Stop'
$summaries = foreach ($name in @('before-group', 'final-group', 'verified-group', 'final-cancel-zoom', 'paged-cancel-zoom', 'verified-cancel-zoom')) {
    $data = Get-Content -LiteralPath "$PSScriptRoot/$name.json" -Raw | ConvertFrom-Json
    if ($data.stage -ne 'complete' -or $data.error) { throw "Incomplete: $name" }
    $operations = @($data.operations | ForEach-Object {
        [ordered]@{name=$_.name; dispatchMs=($_.dispatchEndTicks-$_.startTicks)*1000/$data.stopwatchFrequency;
            completionMs=($_.completionTicks-$_.startTicks)*1000/$data.stopwatchFrequency;
            cancelCompletionMs=$_.cancelToCompletionMs; cancelEditingRecoveredMs=$_.cancelToCanEditMs}
    })
    $warm = $null
    $zoom = $data.phases | Where-Object name -eq 'group-zoom'
    if ($data.navigationMilliseconds -gt 3200) {
        $frames = @(Import-Csv -LiteralPath "$PSScriptRoot/$name-render.csv" | Where-Object {
            [long]$_.stopwatch_start_ticks -gt ($zoom.startTicks + 3.2 * $data.stopwatchFrequency) -and
            [long]$_.stopwatch_end_ticks -lt $zoom.endTicks
        })
        $warm = [ordered]@{fromPhaseSeconds=3.2; frames=$frames.Count;
            submitMaxMs=($frames | Measure-Object submit_ms -Maximum).Maximum;
            uploadedBytes=($frames | Measure-Object roi_upload_bytes -Sum).Sum;
            packMaxMs=($frames | Measure-Object roi_pack_ms -Maximum).Maximum;
            createMaxMs=($frames | Measure-Object roi_create_ms -Maximum).Maximum;
            activeCacheMaxBytes=($frames | Measure-Object roi_cache_bytes -Maximum).Maximum}
    }
    [ordered]@{file=$name;operations=$operations;warmZoom=$warm;undoExact=$data.undoExact;redoExact=$data.redoExact;groupCancelExact=$data.groupCancelExact}
}
$rotations = foreach ($name in @('before-rotation', 'final-rotation', 'verified-rotation', 'verified-cancel-rotation', 'verified-warp-rotation')) {
    $data = Get-Content -LiteralPath "$PSScriptRoot/$name.json" -Raw | ConvertFrom-Json
    if ($data.stage -ne 'complete' -or $data.error) { throw "Incomplete: $name" }
    $commit = $data.operations | Where-Object name -eq 'commit'
    $frames = Import-Csv -LiteralPath "$PSScriptRoot/$name-render.csv"
    $preview = @($frames | Where-Object {
        [long]$_.stopwatch_start_ticks -ge $data.samples[0].StartTicks -and [long]$_.stopwatch_end_ticks -lt $commit.startTicks
    })
    $cpu = @($preview | ForEach-Object { [double]$_.paint_ms + [double]$_.submit_ms })
    $post = @($frames | Where-Object { [long]$_.stopwatch_start_ticks -ge $commit.startTicks })
    [ordered]@{file=$name;adapter=$data.GpuStatus;pointerDownMs=$data.operations[0].dispatchMs;
        emptyPreviewSamples=@($data.samples | Where-Object { $null -eq $_.displayedAngleDegrees }).Count;
        callbackMaxMs=($data.samples | Measure-Object CallbackMs -Maximum).Maximum;
        previewCpuMaxMs=($cpu | Measure-Object -Maximum).Maximum;
        previewUploadedBytes=($preview | Measure-Object roi_upload_bytes -Sum).Sum;
        previewFrames=$preview.Count;commitCompletionMs=$commit.completionMs;commitDispatcherGapMs=$commit.MaxGapMs;
        postCommitSubmitMaxMs=($post | Measure-Object submit_ms -Maximum).Maximum;
        cancellation=$data.cancellation;undoExact=$data.undoExact;redoExact=$data.redoExact}
}
[ordered]@{group=$summaries;rotation=$rotations} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath "$PSScriptRoot/comparison.json"
Get-ChildItem -LiteralPath $PSScriptRoot -File | Where-Object Extension -eq '.dll' | ForEach-Object {
    [ordered]@{file=$_.Name;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
} | ConvertTo-Json | Set-Content -LiteralPath "$PSScriptRoot/binary-hashes.json"
