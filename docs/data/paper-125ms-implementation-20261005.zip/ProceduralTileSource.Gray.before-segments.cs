using System.Runtime.InteropServices;
using System.Runtime.Intrinsics;
using System.Runtime.CompilerServices;
using TeachingToolWpf.Core.Imaging;

namespace TeachingToolWpf.Imaging;

public sealed partial class ProceduralTileSource
{
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public PixelBuffer ReadOriginalGray8(int tileX, int tileY, CancellationToken cancellationToken)
    {
        var left = checked(tileX * ImageInfo.TileSize);
        var top = checked(tileY * ImageInfo.TileSize);
        if (left < 0 || top < 0 || left >= Info.Width || top >= Info.Height)
        {
            throw new ArgumentOutOfRangeException(nameof(tileX));
        }
        var pixels = new PixelBuffer(Math.Min(512, Info.Width - left), Math.Min(512, Info.Height - top), PixelKind.Gray8);
        try
        {
            Span<byte> noise = stackalloc byte[pixels.Width];
            for (var x = 0; x < noise.Length; x++)
            {
                noise[x] = (byte)(((left + x) * 13) & 7);
            }
            var cellLeft = left % 2048;
            for (var y = 0; y < pixels.Height; y++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var cellY = (top + y) % 2048;
                var row = pixels.Span.Slice(y * pixels.Stride, pixels.Width);
                // 동일한 원본 색의 구간만 채운다. 판정 위치/학습 모델은 이 소스에 전달되지 않는다.
                row.Fill(Gray(40, 83, 83));
                Fill(row, cellLeft, cellY - 11, cellY + 12, Gray(95, 133, 116));
                Fill(row, cellLeft, 2048 - cellY - 11, 2048 - cellY + 12, Gray(95, 133, 116));
                if (Math.Min(cellY, 2048 - cellY) < 24)
                {
                    row.Fill(Gray(20, 37, 44));
                }
                else
                {
                    Fill(row, cellLeft, 0, 24, Gray(20, 37, 44));
                    Fill(row, cellLeft, 2025, 2048, Gray(20, 37, 44));
                }
                if ((cellY > 490 && cellY < 640) || (cellY > 1400 && cellY < 1550))
                {
                    for (var pin = 1; pin < 10; pin++)
                    {
                        Fill(row, cellLeft, Math.Max(251, pin * 180), Math.Min(1800, (pin * 180) + 80), Gray(195, 181, 135));
                    }
                }
                if (cellY > 640 && cellY < 1400)
                {
                    Fill(row, cellLeft, 361, 1680, Gray(36, 43, 57));
                }
                var noiseY = (byte)(((top + y) * 7) & 7);
                var offset = 0;
                if (Vector256.IsHardwareAccelerated)
                {
                    var vertical = Vector256.Create(noiseY);
                    for (; offset <= row.Length - Vector256<byte>.Count; offset += Vector256<byte>.Count)
                    {
                        var values = Vector256.LoadUnsafe(ref MemoryMarshal.GetReference(row), (nuint)offset);
                        var horizontal = Vector256.LoadUnsafe(ref MemoryMarshal.GetReference(noise), (nuint)offset);
                        (values + (horizontal ^ vertical)).StoreUnsafe(ref MemoryMarshal.GetReference(row), (nuint)offset);
                    }
                }
                for (; offset < row.Length; offset++)
                {
                    row[offset] += (byte)(noise[offset] ^ noiseY);
                }
            }
            return pixels;
        }
        catch
        {
            pixels.Dispose();
            throw;
        }
    }

    private static byte Gray(int red, int green, int blue) => (byte)(((77 * red) + (150 * green) + (29 * blue) + 128) >> 8);

    private static void Fill(Span<byte> row, int cellLeft, int start, int end, byte value)
    {
        var from = Math.Max(0, start - cellLeft);
        var to = Math.Min(row.Length, end - cellLeft);
        if (to > from)
        {
            row.Slice(from, to - from).Fill(value);
        }
    }
}
