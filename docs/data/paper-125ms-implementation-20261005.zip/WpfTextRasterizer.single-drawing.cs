using System.Collections.Immutable;
using System.Windows;
using System.Windows.Media;
using TeachingToolWpf.Core.Geometry;
using TeachingToolWpf.Rendering;

namespace TeachingToolWpf.Controls;

public sealed partial class WpfTextRasterizer
{
    public TextRasterBatch? RasterizeBatch(IEnumerable<string> texts, double dpi)
    {
        var entries = texts.Distinct(StringComparer.Ordinal).Select(text => (Text: text, Formatted: Format(text, dpi))).ToArray();
        if (entries.Length == 0)
        {
            return null;
        }
        // 32 MiB 이하, 단일 atlas만 보관한다. 큰 DPI/출력은 기존 제한 라벨 캐시로 완성한다.
        var cellWidth = entries.Max(entry => Math.Max(1, (int)Math.Ceiling((entry.Formatted.WidthIncludingTrailingWhitespace + 2) * dpi))) + 2;
        var cellHeight = entries.Max(entry => Math.Max(1, (int)Math.Ceiling((entry.Formatted.Height + 2) * dpi))) + 2;
        var columns = Math.Max(1, 2048 / cellWidth);
        var rows = (entries.Length + columns - 1) / columns;
        var width = Math.Min(columns, entries.Length) * cellWidth;
        var height = rows * cellHeight;
        if (width > 16384 || height > 16384 || (long)width * height > 8 * 1024 * 1024)
        {
            return null;
        }
        var regions = ImmutableDictionary.CreateBuilder<string, BoundsD>(StringComparer.Ordinal);
        var drawing = new DrawingVisual();
        using (var context = drawing.RenderOpen())
        {
            for (var index = 0; index < entries.Length; index++)
            {
                var entry = entries[index];
                var x = (index % columns) * cellWidth + 1;
                var y = (index / columns) * cellHeight + 1;
                var textWidth = Math.Max(1, (int)Math.Ceiling((entry.Formatted.WidthIncludingTrailingWhitespace + 2) * dpi));
                var textHeight = Math.Max(1, (int)Math.Ceiling((entry.Formatted.Height + 2) * dpi));
                regions.Add(entry.Text, new(x, y, x + textWidth, y + textHeight));
                context.DrawText(entry.Formatted, new Point(x / dpi + 1, y / dpi + 1));
            }
        }
        return new(Render(drawing, width, height, dpi), regions.ToImmutable());
    }
}
