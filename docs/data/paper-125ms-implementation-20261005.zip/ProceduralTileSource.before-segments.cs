using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics;
using TeachingToolWpf.Core.Imaging;

namespace TeachingToolWpf.Imaging;

/// <summary>Deterministic, full-resolution sample surface. No source-sized allocation.</summary>
public sealed partial class ProceduralTileSource : ITileSource, IOriginalGrayTileSource
{
    public ImageInfo Info
    {
        get;
    }

    public ProceduralTileSource(int width = 8192, int height = 8192)
        => Info = new($"sample:{width}:{height}", $"검사 샘플 · {width:N0} × {height:N0}", width, height, PixelKind.Rgba32, TilePlanner.LevelCount(width, height));

    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public PixelBuffer Read(TileKey key, CancellationToken cancellationToken)
    {
        var factor = 1 << key.Level;
        var levelWidth = (Info.Width + factor - 1) / factor;
        var levelHeight = (Info.Height + factor - 1) / factor;
        var left = key.X * ImageInfo.TileSize;
        var top = key.Y * ImageInfo.TileSize;
        var result = new PixelBuffer(Math.Min(512, levelWidth - left), Math.Min(512, levelHeight - top), Info.Pixels);
        try
        {
            // 타일 너비는 최대 512다. 행마다 같은 X 조건을 10 KiB 이내의 지역 작업 공간에서 재사용한다.
            Span<int> cells = stackalloc int[result.Width];
            Span<int> packedNoises = stackalloc int[result.Width];
            Span<int> pinMasks = stackalloc int[result.Width];
            Span<int> edgeMasks = stackalloc int[result.Width];
            Span<int> padMasks = stackalloc int[result.Width];
            for (var x = 0; x < result.Width; x++)
            {
                var wx = (left + x) * factor;
                cells[x] = wx % 2048;
                packedNoises[x] = ((wx * 13) & 7) * 0x00010101;
                pinMasks[x] = cells[x] > 250 && cells[x] < 1800 && cells[x] % 180 < 80 ? -1 : 0;
                edgeMasks[x] = Math.Min(cells[x], 2048 - cells[x]) < 24 ? -1 : 0;
                padMasks[x] = cells[x] > 360 && cells[x] < 1680 ? -1 : 0;
            }
            for (var y = 0; y < result.Height; y++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var wy = (top + y) * factor;
                var cellY = wy % 2048;
                var edgeY = Math.Min(cellY, 2048 - cellY) < 24;
                var padY = cellY > 640 && cellY < 1400;
                var pinY = (cellY > 490 && cellY < 640) || (cellY > 1400 && cellY < 1550);
                var noiseY = (wy * 7) & 7;
                var row = result.Span.Slice(y * result.Stride, result.Width * 4);
                var x = 0;
                if (Vector256.IsHardwareAccelerated)
                {
                    var yVector = Vector256.Create(cellY);
                    var noiseVector = Vector256.Create(noiseY * 0x00010101);
                    for (; x <= result.Width - 8; x += 8)
                    {
                        var cellX = Vector256.LoadUnsafe(ref cells[0], (nuint)x);
                        var trace = Vector256.LessThan(Vector256.Abs(cellX - yVector), Vector256.Create(12)) |
                            Vector256.LessThan(Vector256.Abs(cellX + yVector - Vector256.Create(2048)), Vector256.Create(12));
                        var color = Vector256.ConditionalSelect(trace.AsUInt32(), Vector256.Create(0xff74855fu), Vector256.Create(0xff535328u));
                        var edge = edgeY ? Vector256.Create(-1) : Vector256.LoadUnsafe(ref edgeMasks[0], (nuint)x);
                        color = Vector256.ConditionalSelect(edge.AsUInt32(), Vector256.Create(0xff2c2514u), color);
                        if (pinY)
                        {
                            var pin = Vector256.LoadUnsafe(ref pinMasks[0], (nuint)x);
                            color = Vector256.ConditionalSelect(pin.AsUInt32(), Vector256.Create(0xff87b5c3u), color);
                        }
                        if (padY)
                        {
                            var pad = Vector256.LoadUnsafe(ref padMasks[0], (nuint)x);
                            color = Vector256.ConditionalSelect(pad.AsUInt32(), Vector256.Create(0xff392b24u), color);
                        }
                        // 같은 3-bit noise를 RGB에 복제한 뒤 XOR해도 각 채널의 원래 noise와 같다.
                        var noise = (Vector256.LoadUnsafe(ref packedNoises[0], (nuint)x) ^ noiseVector).AsUInt32();
                        color += noise;
                        color.AsByte().StoreUnsafe(ref MemoryMarshal.GetReference(row), (nuint)(x * 4));
                    }
                }
                for (; x < result.Width; x++)
                {
                    var cellX = cells[x];
                    var edge = edgeMasks[x] != 0 || edgeY;
                    var pad = padMasks[x] != 0 && padY;
                    var pin = pinMasks[x] != 0 && pinY;
                    var trace = Math.Abs(cellX - cellY) < 12 || Math.Abs(cellX + cellY - 2048) < 12;
                    var noise = (packedNoises[x] & 7) ^ noiseY;
                    var i = x * 4;
                    row[i] = (byte)((pad ? 36 : pin ? 195 : edge ? 20 : trace ? 95 : 40) + noise);
                    row[i + 1] = (byte)((pad ? 43 : pin ? 181 : edge ? 37 : trace ? 133 : 83) + noise);
                    row[i + 2] = (byte)((pad ? 57 : pin ? 135 : edge ? 44 : trace ? 116 : 83) + noise);
                    row[i + 3] = 255;
                }
            }
            return result;
        }
        catch
        {
            result.Dispose();
            throw;
        }
    }

    public void Dispose()
    {
    }
}
