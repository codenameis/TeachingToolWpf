param([string]$App = 'artifacts/readability-release/TeachingToolWpf.exe')
$ErrorActionPreference = 'Stop'
$appPath = (Resolve-Path -LiteralPath $App).Path
$smoke = Start-Process -FilePath $appPath -ArgumentList '--smoke --gpu-debug --metrics artifacts/readability-smoke.csv --render-profile artifacts/readability-smoke-render.csv' -WindowStyle Hidden -PassThru
if (-not $smoke.WaitForExit(120000)) { throw "Smoke timed out; PID $($smoke.Id)" }
Copy-Item -LiteralPath 'artifacts/smoke.log' -Destination 'artifacts/readability-smoke.log'
Copy-Item -LiteralPath 'artifacts/roi-style-check.json' -Destination 'artifacts/readability-smoke-check.json'
$check = Get-Content -LiteralPath 'artifacts/readability-smoke-check.json' -Raw | ConvertFrom-Json
[pscustomobject]@{ SmokeExit=$smoke.ExitCode; Completed=$check.completed; Errors=$check.newErrors; Error=$check.error } | ConvertTo-Json -Compress
if ($smoke.ExitCode -ne 0 -or -not $check.completed -or $check.error -or $check.newErrors.Count -ne 0) { throw 'Smoke failed' }
foreach ($capture in @('roles','parent-selected','detached','settings')) {
    Copy-Item -LiteralPath "artifacts/roi-style-$capture.png" -Destination "artifacts/readability-after-$capture.png"
}
foreach ($iteration in 1..3) {
    foreach ($layout in @('flat','pcb')) {
        $stem = "artifacts/readability-after-$layout-r$iteration"
        $argsList = @('--roi-rotation-benchmark','--rois','200000','--report',"$stem.json",'--metrics',"$stem.csv",'--render-profile',"$stem-render.csv")
        if ($layout -eq 'pcb') { $argsList += @('--rotation-layout','pcb','--rotation-selection','parents') }
        $process = Start-Process -FilePath $appPath -ArgumentList $argsList -WindowStyle Hidden -PassThru
        if (-not $process.WaitForExit(120000)) { throw "Diagnostic timed out: $stem; PID $($process.Id)" }
        $report = Get-Content -LiteralPath "$stem.json" -Raw | ConvertFrom-Json
        [pscustomobject]@{ Case=$stem; Exit=$process.ExitCode; Stage=$report.stage; Error=$report.error; Undo=$report.undoExact; Redo=$report.redoExact } | ConvertTo-Json -Compress
        if ($process.ExitCode -ne 0 -or $report.error) { throw "Diagnostic failed: $stem" }
    }
}
