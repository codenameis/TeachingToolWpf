# 논문 방식 125 ms 계획용 baseline

측정일: 2026-10-05. 구현 소스·기존 게시물은 수정하거나 새로 빌드하지 않았다.

## kensa.png 신규 측정

원본 1024×1536 파일이며 8K 성능 증거가 아니다. 학습 ROI는 원본 기준 left156/top158/width89/height52, 중심(200.5,184)의 사각형이다. 사용자와 확정한 정답 annotation은 아직 없으며 육안의 검정 메모리칩 약48개와 실제 검출44개의 일대일 mapping도 수행하지 않았다.

실행 파일: src/VisionInspection.Cli/bin/Release/net10.0/VisionInspection.Cli.exe (기존 Release, 2026-10-05 08:53:42). 이 CLI는 새 빌드가 아니며 500ms 검증의 ReadyToRun/AVX2 v4 게시물과 Algorithm/Inspection DLL SHA256이 다르다. runtimeconfig에는 TieredCompilation=false가 없다. hashes.json에 모든 실측 DLL·이미지 해시를 저장했다. 현재 source와 이 build의 완전 일치 여부는 검증하지 않았다.

두 레시피는 논문 모드, ±180도/10도 간격, 배율1, pyramid3/feature160/gradient8, 점수.72, clutter1, 후보2048/원본검증64/거친검증256/출력256, CPU 병렬12이다. cpu와 cuda만 다르다. searchRoi가 없으므로 전체 원본을 검색한다.

각 모드를 독립 프로세스로4회 실행했다. 매번 파일 로더·모델·CUDA 세션을 새로 만들므로 뒤3회는 준비된 동일 세션의 warm 검색이 아니다. GPU SearchMilliseconds에는 최초 CUDA 준비가 들어간다. 첫 측정 뒤 OS/파일 캐시 상태가 달라질 수 있다. CLI ProcessWall은 프로세스 시작·학습·결과 JSON 저장까지, Diagnostics.Total은 파일준비·학습·검색, SearchMilliseconds는 서비스 내부 검색 시간이다. 클릭→화면 표시 시간은 어느 것도 아니다.

| 모드 | 첫 검색ms | 후속 독립3회 최소/중앙/최대ms | 결과 |
|---|---:|---:|---|
| CPU | 1906.5284 | 1503.6967 / 1509.1334 / 1614.7233 | 매회44개, incomplete, exit2 |
| CUDA | 3323.3354 | 1899.1317 / 2009.3578 / 2112.4859 | 매회44개, incomplete, exit2 |

8회 전부 CPU 첫 matches의 공개 JSON과 정확히 같다. 검색 창4개 중 candidate budget 초과3개, verification budget 초과1개이며 출력 상한 초과는 아니다. CUDA 후보 계산만4회·약20~21ms, 전처리 GPU 호출0이다. 정확도/완전성/125ms/80ms 달성을 주장하지 않는다.

재현(저장소 루트, 반복마다 output 이름 변경):

```powershell
./src/VisionInspection.Cli/bin/Release/net10.0/VisionInspection.Cli.exe --recipe artifacts/paper-125ms-baseline-20261005/kensa-paper-cpu.json --output artifacts/paper-125ms-baseline-20261005/kensa-paper-cpu-run0.json
./src/VisionInspection.Cli/bin/Release/net10.0/VisionInspection.Cli.exe --recipe artifacts/paper-125ms-baseline-20261005/kensa-paper-cuda.json --output artifacts/paper-125ms-baseline-20261005/kensa-paper-cuda-run0.json
```

## sample:8192:8192 기존 보고서 보존

sample-paper-v4-existing-report.json은 artifacts/shape-500ms-v4.json의 논문 행만 추출한 기존 증거다. 이번 재실행이 아니다. 해당 sample 서비스 CPU/GPU 반복 중앙값은336.9/305.6ms, 첫399.2/342.4ms, 각각256핀 일대일과 CPU/GPU 동등. 원본 보고서의 기하 초기화 이력까지 preparation 원문에는 보존될 수 있다.

기존 shape-target benchmark에는 CPU/GPU 필터만 있고 논문/기하 필터가 없어 항상 둘을 모두 실행한다. paper-pins는 논문 CPU만 가능하고 출력상한1000·clutter0로 현재 수용설정과 다르다. CLI는 실제 파일경로만 허용해 sample URI를 직접 지원하지 않는다. 따라서 구현 변경 없이 논문만/동일세션 첫+반복3회/동일설정의 sample CPU와GPU를 새로 재는 공개 명령은 없다. 기존 v4 증거와 신규 kensa CLI 숫자를 구현 전후 성능 비교로 합치지 않는다.

## 앱 sample 신규 실행 — 후속 보완

위 실행 제약은 유지되지만 논문 수치를 새로 확인하기 위해 기존 v4 shape-target를 실행했다. 도구가 자체기하 검사도 함께 수행한 전체 원본은 sample-v4-fresh-full-report.json에 보존하며 논문행은 sample-paper-v4-fresh-report.json에 추출했다. 알고리즘 구현·build 변경은 없고 테스트 실행만 수행했다. 위 sample-paper-v4-existing-report.json과 구분하며 신규 실측의 주 근거는 fresh 보고서다.

```powershell
./artifacts/shape-500ms-v4-bin/TeachingToolWpf.Matching.Benchmarks.exe artifacts/paper-125ms-baseline-20261005/sample-v4-fresh-full-report.json shape-target 3 12 both
```

원본sample:8192:8192, v4 ReadyToRun/AVX2·TieredCompilation=false, CPU12, 학습 ROI 및 옵션은 이전 고정500ms조건과 같다. 각 모드 첫1회와 동일세션 반복3회이고 CPU/GPU 순서를 교대한다. 논문 검사가 먼저 실행되고 CPU 첫 행만 프로세스의 첫 검색이다. 학습과 CUDA 준비는 검색 시간에서 제외한다. 원본읽기·픽셀생성·전처리·후보·원본검증·결과조립·lease반환이 포함된 서비스 호출 wall이며 앱 버튼→화면표시 측정은 아니다.

| 논문 mode | 첫 검색ms | 반복3회 최소/중앙/최대ms |
|---|---:|---:|
| CPU12 | 479.3 | 322.0 / 340.3 / 350.4 |
| CUDA 혼합 | 395.9 | 291.0 / 296.9 / 316.4 |

논문8회 모두256개 일대일·CPU/GPU 최종record 동등·누락/중복없음·잘림/출력상한없음·사선점수 간격.0294648. CUDA 최초 준비626.3ms 별도이므로 첫GPU 준비+검색은약1022.2ms이다. 기준 CPU125ms/GPU80ms는 서비스만으로도 모두 미달이다. 기존 benchmark exit0은 과거500ms 기준·전체정확성의 통과이며 새목표 PASS로 해석하지 않는다. 다른 binary인 kensa CLI와 전후 속도개선 비교에 사용하지 않는다.
