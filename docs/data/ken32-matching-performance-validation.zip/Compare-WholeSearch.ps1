param([string]$Before, [string[]]$After, [string]$Output)
$ErrorActionPreference = 'Stop'
$reference = Get-Content -LiteralPath $Before -Raw | ConvertFrom-Json
$reference.Output.Result.Timings = $null
$rows = foreach ($path in $After) {
    $actual = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    $times = $actual.Output.Result.Timings
    $actual.Output.Result.Timings = $null
    foreach ($property in 'Options', 'Teaching', 'Image', 'Method', 'UseCuda') {
        if (($reference.$property | ConvertTo-Json -Depth 30 -Compress) -cne ($actual.$property | ConvertTo-Json -Depth 30 -Compress)) {
            throw "Different input or options: $property ($path)"
        }
    }
    if (($reference.Output.Result | ConvertTo-Json -Depth 30 -Compress) -cne ($actual.Output.Result | ConvertTo-Json -Depth 30 -Compress)) {
        throw "Different results/candidates/evaluations: $path"
    }
    if (($reference.Profile.Stages | ConvertTo-Json -Depth 30 -Compress) -cne ($actual.Profile.Stages | ConvertTo-Json -Depth 30 -Compress)) {
        throw "Different complete intermediate stages: $path"
    }
    [pscustomobject]@{
        File = $path
        TotalMs = $actual.Output.TotalMilliseconds
        ReadMs = $actual.Output.ReadMilliseconds
        Stages = $times
        Speedup = $reference.Output.TotalMilliseconds / $actual.Output.TotalMilliseconds
        GainPercent = 100 * (1 - $actual.Output.TotalMilliseconds / $reference.Output.TotalMilliseconds)
        Matches = $actual.Output.Result.Matches.Count
        Candidates = $actual.Output.Result.CandidateCount
        Evaluations = $actual.Output.Result.Evaluations
        FullStageHashesEqual = $true
        Maps = $actual.Profile.Maps
        PeakWorkingSetBytes = $actual.PeakWorkingSetBytes
    }
}
$rows | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $Output -Encoding utf8
$rows | Select-Object File, TotalMs, ReadMs, Speedup, GainPercent, Candidates, Evaluations, FullStageHashesEqual | Format-Table -AutoSize
