import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent.parent
files = [
    ("cpu-split-modules-final.json", 54, True),
    ("cpu-split-boundary-final.json", 9, True),
    ("cpu-split-aligned-final.json", 27, True),
    ("cpu-split-aligned-boundary.json", 9, False),
    ("cpu-split-workers8.json", 3, True),
    ("cpu-split-controlled-line.json", 9, True),
    ("cpu-split-controlled-chamfer.json", 9, True),
    ("cpu-split-controlled-line-boundary.json", 3, True),
    ("cpu-split-controlled-chamfer-boundary.json", 3, True),
    ("cpu-split-controlled-line-negative.json", 3, False),
    ("cpu-split-controlled-chamfer-negative.json", 3, False),
]
summaries = []
for filename, expected_rows, expect_success in files:
    path = root / "artifacts" / filename
    if not path.exists():
        continue
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    rows = data["Rows"]
    assert len(rows) == expected_rows, (filename, len(rows))
    assert data.get("Complete", True), filename
    assert data["Passed"] == expect_success, filename
    grouped = {}
    for row in rows:
        options = row["Options"]
        assert options["MinimumScore"] == .75
        assert (options["MinimumAngle"], options["MaximumAngle"], options["AngleStep"]) == (-30, 30, 10)
        assert options["MinimumScale"] == options["MaximumScale"] == 1
        assert options["CandidateLimit"] == 2048 and options["MaximumMatches"] == 256
        assert not row["Result"]["CandidatesTruncated"]
        assert not row["Result"]["MatchLimitExceeded"]
        if row["Tiles"] > 1:
            tiles = row["Partitions"]
            cores = [tile["Tile"]["Core"] for tile in tiles]
            assert len(tiles) == row["Tiles"]
            assert sum(core["Width"] * core["Height"] for core in cores) == row["Width"] * row["Height"]
            for i, tile in enumerate(tiles):
                core = tile["Tile"]["Core"]
                read = tile["Tile"]["Read"]
                assert read["X"] % 4 == read["Y"] % 4 == 0
                assert 0 <= read["X"] <= core["X"] < core["X"] + core["Width"] <= read["X"] + read["Width"] <= row["Width"]
                assert 0 <= read["Y"] <= core["Y"] < core["Y"] + core["Height"] <= read["Y"] + read["Height"] <= row["Height"]
                for other in cores[i + 1:]:
                    assert (core["X"] + core["Width"] <= other["X"] or other["X"] + other["Width"] <= core["X"]
                            or core["Y"] + core["Height"] <= other["Y"] or other["Y"] + other["Height"] <= core["Y"])
        grouped.setdefault((row["Name"], row["Method"], row.get("Padding", "overlap"), row["Tiles"], row["Workers"]), []).append(row)
    for key, group in grouped.items():
        assert len({json.dumps(r["Options"], sort_keys=True) for r in group}) == 1
        assert len({r["ImageSha256"] for r in group}) == 1
        assert len({r["TemplateSha256"] for r in group}) == 1
        first = group[0]
        assert all(r["Result"]["Matches"] == first["Result"]["Matches"] for r in group)
        summaries.append(dict(
            Source=filename, Case=key[0], Method=key[1], Padding=key[2], Tiles=key[3], Workers=key[4], Runs=len(group),
            MedianMs=statistics.median(r["Milliseconds"] for r in group), MaxMs=max(r["Milliseconds"] for r in group),
            Found=len(first["Result"]["Matches"]), Passed=all(r["Accuracy"]["Passed"] for r in group),
            MaxPosition=max(r["Accuracy"]["MaximumPositionError"] for r in group),
            MaxAngle=max(r["Accuracy"]["MaximumAngleError"] for r in group),
            BaselinePosition=max(r["BaselineAgreement"]["MaximumPositionError"] for r in group),
            Missing=first["Accuracy"]["Missing"], Extra=first["Accuracy"]["Extra"],
            ReadRatio=first["ReadPixels"] / (first["Width"] * first["Height"]),
            Candidates=first["Result"]["CandidateCount"], Evaluations=first["Result"]["Evaluations"],
            MedianAllocatedMiB=statistics.median(r["AllocatedBytes"] for r in group) / 1024**2,
            CpuToWall=statistics.median(r["CpuMilliseconds"] / r["Milliseconds"] for r in group),
        ))
(root / "artifacts/cpu-split-summary.json").write_text(json.dumps(summaries, ensure_ascii=False, indent=2), encoding="utf-8")
for item in summaries:
    print(f'{item["Case"]:20s} {item["Method"]:18s} {item["Padding"]:7s} {item["Tiles"]:2d} '
          f'median={item["MedianMs"]:9.1f}ms max={item["MaxMs"]:9.1f}ms found={item["Found"]:3d} '
          f'pass={item["Passed"]} read={item["ReadRatio"]:.2f}x candidates={item["Candidates"]}')

for new_file, old_file in [
    ("cpu-split-controlled-line.json", "cpu-split-aligned-final.json"),
    ("cpu-split-controlled-chamfer.json", "cpu-split-aligned-final.json"),
    ("cpu-split-controlled-line-boundary.json", "cpu-split-boundary-final.json"),
    ("cpu-split-controlled-chamfer-boundary.json", "cpu-split-boundary-final.json"),
    ("cpu-split-controlled-line-negative.json", "cpu-split-aligned-boundary.json"),
    ("cpu-split-controlled-chamfer-negative.json", "cpu-split-aligned-boundary.json"),
]:
    if not (root / "artifacts" / new_file).exists():
        continue
    old = json.loads((root / "artifacts" / old_file).read_text(encoding="utf-8-sig"))["Rows"]
    new = json.loads((root / "artifacts" / new_file).read_text(encoding="utf-8-sig"))["Rows"]
    for row in new:
        original = next(r for r in old if all(r[k] == row[k] for k in ("Name", "Method", "Tiles", "Repeat")))
        for key in ("Matches", "Evaluations", "CandidateCount", "CandidateBatches", "CandidatesTruncated", "MatchLimitExceeded"):
            assert row["Result"][key] == original["Result"][key], (new_file, row["Tiles"], key)
print("Serial map preparation vs prior parallel preparation: exact results/evaluations/candidates PASS")
