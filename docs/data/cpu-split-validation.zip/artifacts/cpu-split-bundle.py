import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
sources = [
    "src/CpuMatching.Core/Contracts.cs", "src/CpuMatching.Core/PyramidSearch.cs",
    "src/CpuMatching.Line2D/Line2DMatcher.cs", "src/CpuMatching.DirectionalChamfer/DirectionalChamferMatcher.cs",
    "tools/CpuMatching.Evaluation/Program.cs", "tools/CpuMatching.Evaluation/SplitBenchmark.cs",
    "tools/CpuMatching.Evaluation/TiledInspection.cs", "tests/CpuMatching.Tests/FullSearchAccuracyTests.cs",
    "docs/cpu-matching-split-experiment.md",
]
inputs = [
    "samples/CpuMatching.Modules/cases.json", "samples/CpuMatching.Modules/kensa.png",
    "samples/CpuMatching.Modules/kensa-template.png", "samples/CpuMatching.Modules/8k-modules.png",
    "samples/CpuMatching.Modules/pin-template.png", "samples/CpuMatching.FullImage/cases.json",
    "samples/CpuMatching.FullImage/template.png", "samples/CpuMatching.FullImage/8k-full-eight.png",
]
binaries = [f"artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/{name}.dll" for name in
            ("CpuMatching.Evaluation", "CpuMatching.Core", "CpuMatching.Line2D", "CpuMatching.SubNcc", "CpuMatching.DirectionalChamfer")]
hashes = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sources + inputs + binaries}
manifest = dict(
    Head=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    Branch=subprocess.check_output(["git", "branch", "--show-current"], cwd=root, text=True).strip(),
    Scope="Local CPU experiment on pre-aligned images. Images and native dependencies remain local; no commit/push.",
    Hardware="Ryzen 5 5600H / 32 GB / RTX 3060 Laptop 6 GB; Windows x64; .NET 10 Release",
    SourcesAndInputsSha256=hashes,
    Provenance={
        "cpu-split-ncc-probe.json": "First exploratory run before serial spatial ordering was restored.",
        "cpu-split-modules-final.json": "Initial 54 overlap runs; Line2D/Chamfer still had nested map preparation of 4 workers.",
        "cpu-split-aligned-final.json": "Initial 27 no-halo runs; only SubNcc is reused as the final 4-worker result (has no nested map preparation).",
        "cpu-split-boundary-final.json": "Initial overlap boundary correctness, 9 rows.",
        "cpu-split-aligned-boundary.json": "Initial no-halo boundary negative test, 6 expected failed rows.",
        "cpu-split-workers8.json": "One exploratory repeat, SubNcc only, 8 workers.",
        "cpu-split-controlled-*.json": "Final Line2D/Chamfer: serial tile preparation and serial tile scoring. Whole-image default remains 4 workers per stage."
    })
(root / "artifacts/cpu-split-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
files = [(root / name) for name in sources]
files += sorted(path for path in (root / "artifacts").glob("cpu-split-*") if path.is_file())
destination = root / "docs/data/cpu-split-validation.zip"
with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        archive.write(path, str(path.relative_to(root)))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
print(f"{destination}: {destination.stat().st_size:,} bytes; {len(files)} files; CRC PASS")
