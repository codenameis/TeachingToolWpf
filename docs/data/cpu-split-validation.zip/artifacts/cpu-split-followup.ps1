$ErrorActionPreference = 'Stop'
$splitExitCodes = @{}
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.Modules artifacts/cpu-split-aligned-final.json 8k-full-modules 3 all 4 aligned | Tee-Object -FilePath artifacts/cpu-split-aligned-final.log
$splitExitCodes.AlignedModules = $LASTEXITCODE
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.FullImage artifacts/cpu-split-boundary-final.json all 1 all 4 overlap | Tee-Object -FilePath artifacts/cpu-split-boundary-final.log
$splitExitCodes.OverlapBoundary = $LASTEXITCODE
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.FullImage artifacts/cpu-split-aligned-boundary.json all 1 all 4 aligned | Tee-Object -FilePath artifacts/cpu-split-aligned-boundary.log
$splitExitCodes.AlignedBoundary = $LASTEXITCODE
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.Modules artifacts/cpu-split-workers8.json 8k-full-modules 1 SubNcc 8 aligned | Tee-Object -FilePath artifacts/cpu-split-workers8.log
$splitExitCodes.Workers8 = $LASTEXITCODE
$splitExitCodes | ConvertTo-Json | Set-Content artifacts/cpu-split-followup-exit-codes.json
if ($splitExitCodes.AlignedModules -ne 0 -or $splitExitCodes.OverlapBoundary -ne 0 -or $splitExitCodes.Workers8 -ne 0 -or $splitExitCodes.AlignedBoundary -ne 2) {
    exit 2
}
