$ErrorActionPreference = 'Stop'
$controlledExitCodes = @{}
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.Modules artifacts/cpu-split-controlled-line.json 8k-full-modules 3 Line2D 4 aligned | Tee-Object -FilePath artifacts/cpu-split-controlled-line.log
$controlledExitCodes.LineModules = $LASTEXITCODE
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.Modules artifacts/cpu-split-controlled-chamfer.json 8k-full-modules 3 DirectionalChamfer 4 aligned | Tee-Object -FilePath artifacts/cpu-split-controlled-chamfer.log
$controlledExitCodes.ChamferModules = $LASTEXITCODE
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.FullImage artifacts/cpu-split-controlled-line-boundary.json all 1 Line2D 4 overlap | Tee-Object -FilePath artifacts/cpu-split-controlled-line-boundary.log
$controlledExitCodes.LineBoundary = $LASTEXITCODE
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.FullImage artifacts/cpu-split-controlled-chamfer-boundary.json all 1 DirectionalChamfer 4 overlap | Tee-Object -FilePath artifacts/cpu-split-controlled-chamfer-boundary.log
$controlledExitCodes.ChamferBoundary = $LASTEXITCODE
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.FullImage artifacts/cpu-split-controlled-line-negative.json all 1 Line2D 4 aligned | Tee-Object -FilePath artifacts/cpu-split-controlled-line-negative.log
$controlledExitCodes.LineNegative = $LASTEXITCODE
& 'artifacts/sidebar-verified/bin/CpuMatching.Evaluation/release/CpuMatching.Evaluation.exe' split samples/CpuMatching.FullImage artifacts/cpu-split-controlled-chamfer-negative.json all 1 DirectionalChamfer 4 aligned | Tee-Object -FilePath artifacts/cpu-split-controlled-chamfer-negative.log
$controlledExitCodes.ChamferNegative = $LASTEXITCODE
$controlledExitCodes | ConvertTo-Json | Set-Content artifacts/cpu-split-controlled-exit-codes.json
if ($controlledExitCodes.LineModules -ne 0 -or $controlledExitCodes.ChamferModules -ne 0 -or $controlledExitCodes.LineBoundary -ne 0 -or $controlledExitCodes.ChamferBoundary -ne 0 -or $controlledExitCodes.LineNegative -ne 2 -or $controlledExitCodes.ChamferNegative -ne 2) {
    exit 2
}
