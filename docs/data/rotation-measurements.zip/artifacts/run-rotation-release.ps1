$ErrorActionPreference = 'Stop'
$exe = Join-Path $PSScriptRoot 'rotation-release/TeachingToolWpf.exe'
$root = Split-Path $PSScriptRoot -Parent
$cases = @(
    @{ Name='200k-pcb-parents-1'; Count=200000; Extra='--rotation-layout pcb --rotation-selection parents' },
    @{ Name='200k-pcb-parents-2'; Count=200000; Extra='--rotation-layout pcb --rotation-selection parents' },
    @{ Name='200k-pcb-parents-3'; Count=200000; Extra='--rotation-layout pcb --rotation-selection parents' },
    @{ Name='40k-interior'; Count=40000; Extra='' },
    @{ Name='200k-interior'; Count=200000; Extra='' },
    @{ Name='400k-interior'; Count=400000; Extra='--capture-rotation' },
    @{ Name='40k-half'; Count=40000; Extra='--rotation-selection half' },
    @{ Name='40k-boundary'; Count=40000; Extra='--rotation-mode boundary' },
    @{ Name='200k-onecpu'; Count=200000; Extra=''; OneCpu=$true },
    @{ Name='40k-debug'; Count=40000; Extra='--gpu-debug --rotation-samples 60 --capture-rotation' }
)
foreach ($case in $cases) {
    $stem = 'artifacts/rotation-release-' + $case.Name
    $arguments = '--roi-rotation-benchmark --rois ' + $case.Count + ' ' + $case.Extra + ' --report ' + $stem + '.json --metrics ' + $stem + '.csv --render-profile ' + $stem + '-render.csv'
    $process = Start-Process -FilePath $exe -WorkingDirectory $root -ArgumentList $arguments -PassThru -WindowStyle Hidden
    if ($case.OneCpu) { $process.ProcessorAffinity = [IntPtr]1 }
    $process.WaitForExit()
    $report = Get-Content -LiteralPath ($stem + '.json') -Raw | ConvertFrom-Json
    [pscustomobject]@{Case=$case.Name;Exit=$process.ExitCode;Stage=$report.stage;Error=$report.error;Undo=$report.undoExact;Redo=$report.redoExact} | ConvertTo-Json -Compress
    if ($process.ExitCode -ne 0 -or $report.stage -ne 'complete' -or $report.error) { throw ('Failed: ' + $case.Name) }
}
