# ROI 회전 측정 원시 자료 (2026-10-02)

이 압축 파일을 저장소 루트에 풀면 `artifacts/` 아래에 원시 JSON/CSV와 캡처가 복원된다.
조건, 미검증 범위, 수치 해석은 `docs/rotation-performance.md`를 기준으로 한다.

- `rotation-before-*`: 기존 구현. schema 1, 2회 워밍업 + 10회 측정, 각 입력 후 파일 저장.
- `rotation-after-*`: 공통 변환 preview, BVH refit 전. schema 2, 루프 뒤 파일 저장.
- `rotation-final-*`: BVH refit 포함, 최초 선택 준비 worker 이전의 중간 버전.
- `rotation-ready-*`: 최초 준비 worker 적용, FrozenSet 및 취소 worker 직렬화 이전.
- `rotation-release-*`: 최종 구현. FrozenSet, worker 직렬화 포함. 최종 비교 기준.
- `rotation-commit-*`: UI/GPU 제외 CPU 확정 단계 진단. 앱 complete 시간과 구분.
- `rotation-overlap-*`: 겹친 4만 ROI의 별도 pan 진단. 연속 회전 시험이 아니다.
- `smoke.log`, `filter-rotation-smoke.png`: 최종 실제 RTX/DX12 debug 통합 검증.

`rotation-release-summary.json`의 Measured는 준비 대기를 포함한 전체 입력이다.
DisplayedMeasured는 callback 때 preview가 관측된 입력만이며, WaitingMeasuredSamples는 준비 중 입력이다.
FirstPreview.RenderPreparationEndMs는 첫 preview 렌더 명령 준비 완료까지로, Present/모니터 표시 지연이 아니다.
스크립트는 schema 1의 단계 혼합 렌더 수치를 회전 성능으로 집계하지 않는다.

재집계:

```powershell
./scripts/Summarize-RoiRotation.ps1 -Path 'artifacts/rotation-release-*.json' -IncludeMetrics -Format Json
```

`run-rotation-release.ps1`은 측정 당시 10개 조건을 순차 실행한 명령이다. 별도 측정 바이너리를
`dotnet publish TeachingToolWpf.csproj -c Release -o artifacts/rotation-release`로 준비한 뒤 실행한다.
실행 시 해당 이름의 산출물을 새로 쓴다. 바이너리 자체는 이 압축 파일에 포함하지 않는다.
`rotation-binary-hashes.json`은 보관 중인 단계별 DLL/셰이더 해시다.
