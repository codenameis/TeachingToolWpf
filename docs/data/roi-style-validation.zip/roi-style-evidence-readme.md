# ROI 표시 설정 검증 원시 자료

2026-10-02 Release, AMD Ryzen 5 5600H / RTX 3060 Laptop GPU / RAM 32 GB.
역할별 두께 설정과 부모 핑크색 추가 후의 기능·성능 회귀 확인이다.

- `roi-style-check.json`: 실제 앱 설정 입력/버튼 적용, HWND 자식 이탈, Undo/Redo, 초기화의 검증 결과.
- `roi-style-*.png`: 같은 최종 smoke에서 캡처한 실제 GPU 출력 및 전체 설정 패널.
- `roi-style-final-smoke.log`: DX12 debug 장치와 기존 입력/필터/미니맵/라이브 검증 결과.
- `roi-style-final-smoke*.csv`: smoke 중 렌더러 재시작 시 파일이 다시 생성되어 마지막 렌더 구간만 포함한다. 스타일 적용 순간의 업로드 실측 자료로 사용하지 않는다.
- `roi-style-final-rotation-200k-{flat,pcb}.*`: 고정 8192×8192 합성 배경과 20만 ROI, 2회 워밍업 + 180회 입력 표본. flat 전체 선택, PCB 부모 선택(22,223개, 영향 ROI 20만 개). 기존 화면 밀도 LOD와 중복 도형 합치기 사용.
- `roi-style-final-rotation-summary.json`: 프로젝트 `scripts/Summarize-RoiRotation.ps1`로 만든 요약. 입력 콜백 시간은 전체 프레임 시간이나 물리 모니터 지연이 아니다.
- `roi-style-binary-hashes.json`: 최종 실행 검증본 바이너리/셰이더 SHA-256.

Core 158개 + Imaging/WPF 97개 자동 테스트 통과, Release 빌드 경고/오류 0.
개별 두께 적용에 따른 캐시 재사용은 자동 테스트와 코드 경로로 검증했으며 실제 적용 순간의 GPU 업로드 바이트는 위 smoke CSV로 입증하지 않는다.
반복 회전 구간 업로드는 두 회전 CSV에서 실제 0 B다. 초기 준비·확정·이력의 지연이 남아 있으며 모든 구간 무지연 또는 저사양 GPU 성능 목표 달성의 증거가 아니다.
